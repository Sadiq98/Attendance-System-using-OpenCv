"# attendance_system" 
install opencv and tkinter in anaconda and run attendance.py and enjoy.

Face recognition is an important application of Image processing owing to its use in many ends. 
Identification of individuals in any organization for the purpose of attendance is one such application of face recognition. 
Maintenance and monitoring of attendance records play a vital role in the analysis of the performance of any organization. 
The purpose of developing an attendance management system is to computerize the traditional way of taking attendance. Automated Attendance Management System performs the daily activities of attendance marking with reduced human intervention. 
Although many different algorithms exist to perform face detection, each has its own weaknesses and strengths. 
Some use tones, some use contours, and others are even more complex involving templates, neural networks. 
These algorithms suffer from the same problem; they are computationally expensive. 
An image is only a collection of color or light intensity values. 
Analyzing these pixels for face detection is time-consuming and di cult to accomplish because of the wide variations of shape and In this system, we tend to use Haar Classier provided by OpenCV (Open source Computer Vision), Object Detection using Haar feature-based cascade classier is an effective object detection method proposed by Paul Viola and Michael Jones. 
It is a machine learning-based approach where a cascade function is trained from a lot of positive and negative images. 
OpenCV provides both trainers as well as a detector which makes the integration of the Face Recognition system easier. 
The system will mark the attendance within the excel sheet and the following excel sheet will be uploaded on to the Google Firebase Cloud system so the same uploaded data can also be accessed by other authorized users via an Android application.

